// Data Table JavaScripts

(function ($) {
	'use strict';
    
	$('#dt-opt').DataTable();

})(jQuery);
